# Janyaa BCP Hub — Design System

A warm, credible design system for the **Janyaa BCP Hub**, the club-operations platform for Janyaa BCP (the Bellarmine College Prep chapter of the [Janyaa Foundation](https://janyaa.org), a STEM-education nonprofit). The Hub tracks member hours, events, fundraising, and location scouting.

This system exists to be **applied onto the real product** — a React + Vite + Tailwind v4 app. Hand it (plus the token files) to a coding agent or developer and they have everything needed to build on-brand screens.

> **Grounding:** Every color comes from the actual Janyaa BCP badge — Bellarmine blue, the Janyaa green wordmark, the rising-sun gradient, and the two sprouting leaves. Nothing here was invented from scratch.

---

## Index — what's in this folder

| File | Purpose |
|------|---------|
| `style-guide.html` | The visual showpiece. Open it in a browser to see colors, type, components, and in-context examples. Review here first. |
| `colors_and_type.css` | **Source of truth.** Framework-agnostic CSS custom properties: color scales, semantic roles, type, spacing, radii, shadows, motion. |
| `tailwind-theme.css` | Tailwind v4 `@theme` block. `@import` after `tailwindcss` to generate `bg-primary`, `font-display`, `rounded-card`, etc. |
| `assets/janyaa-bcp-logo.png` | The club badge. |
| `ui_kits/janyaa-hub/` | High-fidelity recreation of core Hub screens using the system (member hub, fundraising, events, scouting map, AI insights). A north-star, not production code. |
| `SKILL.md` | Makes this folder usable as a downloadable Claude Code / Agent Skill. |

---

## How to use (React + Vite + Tailwind v4)

1. Copy `colors_and_type.css` and `tailwind-theme.css` into the project (e.g. `src/styles/`).
2. In your main stylesheet:
   ```css
   @import "tailwindcss";
   @import "./styles/tailwind-theme.css";
   ```
3. Load the three fonts (Google Fonts `<link>` in `index.html`, or self-host into `/fonts`). See **Typography**.
4. Build with the semantic utilities — `bg-primary text-white rounded-lg`, `font-display`, `text-ink`, `border-line`, `shadow-card`. Prefer **semantic tokens** (`primary`, `ink`, `line`, `danger`) over raw scale steps so a future re-theme is one-file.

If not using Tailwind, consume `colors_and_type.css` directly: `color: var(--text); background: var(--primary);` etc.

---

## CONTENT FUNDAMENTALS — voice & copy

The Hub is run **by high-schoolers, for high-schoolers**, on behalf of a serious nonprofit. The voice is **warm, plain, and direct** — never corporate, never cutesy.

- **Person:** Address the member as **"you."** Refer to the club as **"the club"** or "Janyaa BCP," never "we the platform."
- **Tone:** Encouraging but factual. Celebrate real milestones (a funded term, a completed event) without hype. Mirror Janyaa's own mission language: *"Study, Teach, Learn."*
- **Casing:** Sentence case for everything — buttons, headings, labels, nav. Only `Space Mono` overlines are UPPERCASE.
- **Numbers carry weight:** Hours, dollars, and counts are the product. Always format cleanly — `24.5 hrs`, `$1,230`, `8 / 12 meetings`. Use tabular figures so columns align.
- **Buttons are verbs:** "Approve hours," "Log donation," "Add event," "Mark attendance." Not "Submit," not "OK."
- **Empty states are kind and actionable:** "No hours logged yet — add your first session." Never a dead end.
- **No emoji** in product UI. The brand's warmth comes from color, type, and the sun/sprout motifs, not emoji.
- **Microcopy examples:**
  - Approval pending → "Waiting on a lead to approve."
  - Goal progress → "$1,230 raised of $4,500 — 27% of the term goal."
  - Error → "Must be a @bcp.org address." (specific, no blame)

---

## VISUAL FOUNDATIONS

### Color
Four brand hues, each a 10-step scale, on warm paper-and-ink neutrals.

| Role | Color | Base hex | Use |
|------|-------|----------|-----|
| **Primary** | Janyaa Green | `#2a943b` | Primary actions, brand, success, approved status. **One primary action per screen.** |
| **Secondary** | Bellarmine Blue | `#1c5892` | Structure, navigation, links, info, scheduled status. Also the best **dark UI surface**. |
| **Accent** | Sun Gold | `#fba631` | Fundraising, progress, highlights, "needs attention" / pending. Use sparingly — it's a spotlight. |
| **Decorative** | Leaf Lime | `#92c952` | Illustration, the sprout motif, fresh soft-positive backgrounds. Not for text or primary UI. |
| **Danger** | Coral | `oklch(0.555 0.190 27)` | Destructive only. Not in the logo; lowest-chroma match. |

**Rules:**
- Neutrals are **warm** (hue ~80, near-zero chroma) — never pure grey. Paper `#f8f6f1`-ish, ink `#3a352e`-ish.
- Color = meaning. A green button always means "go / approve." Don't use brand color for decoration where neutral would do.
- Gold has low contrast on white — for **gold text** use `--gold-700`+; for gold **fills**, put dark text on top.
- Green primary uses `--green-600` for buttons (AA contrast with white); `--green-500` (`#2a943b`) is the brand reference swatch.

### Typography
Three families, distinct jobs (all Google Fonts):

- **Bricolage Grotesque** (display) — headings H1–H3, big numbers, hero. Weights 600–800. Warm, characterful, modern. Tight tracking (`-0.02em`).
- **Hanken Grotesk** (UI/body) — body, labels, table cells, buttons. Weights 400–700. Clean and legible at 14–16px.
- **Space Mono** — overlines, metadata, and tabular data (hours/$). Uppercase `+0.08em` for overlines.

Scale: display clamp 40–56 · H1 36 · H2 28 · H3 22 · H4 18 · body 16 · small 14 · caption 12 · overline 11. Body line-height 1.6; headings 1.1–1.28. **Never below 14px** for UI text.

Font loading:
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400..800&family=Hanken+Grotesk:ital,wght@0,400..800;1,400..600&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
```

### Spacing, radii, layout
- **4px base spacing scale** (`--space-1` = 4px … `--space-24` = 96px). Use `gap` on flex/grid, not margins between siblings.
- **Radii:** inputs/small `10px`, buttons/chips `14px`, cards `18px`, modals/feature panels `26px`, status pills full. Friendly but composed.
- **Layout:** content max-width ~1080px; generous whitespace; responsive single-column under 900px. Sidebar nav on desktop collapses to a top bar on mobile.

### Elevation
Soft, **warm-tinted** shadows (`rgba(38,32,20,…)`) — never pure black/grey. `xs`–`sm` on resting cards; `lg`/`xl` for menus and modals. Borders are 1px `--border` (`--neutral-200`) hairlines. Cards = surface + hairline border + `shadow-sm`.

### Backgrounds & motifs
- App background is warm paper, not white. Cards are near-white surface.
- **Signature gradients:** `--grad-sun` (gold radial, for hero/fundraising flourishes) and `--grad-sprout` (lime→green). Use as accents on hero panels and progress bars — not full-page washes.
- The badge's **sun + two leaves** is the core visual metaphor: growth, warmth, hands cupping a seed. Echo it with radial gold glows in corners and the sprout gradient on positive/progress moments. Avoid literal SVG redraws — use the real logo PNG.

### Motion
Calm and quick. `--ease-out` (`cubic-bezier(0.22,1,0.36,1)`), durations 120–320ms. Buttons dip 1px on press; focus shows a 3px green ring; hovers deepen fill or background. No bounce, no parallax.

---

## ICONOGRAPHY

- **Library:** [Lucide](https://lucide.dev) — clean, friendly, consistent 2px-stroke outline icons. Matches the system's warm-but-credible tone.
  - React: `npm i lucide-react` → `import { Clock, Users, MapPin } from 'lucide-react'`.
  - HTML/prototype: `<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>` then `<i data-lucide="clock"></i>` + `lucide.createIcons()`.
- **Stroke & size:** 2px stroke; 16px in dense UI, 18–20px in cards/headers, 24px max. Icons inherit text color or use the role color (e.g. green clock for hours).
- **No emoji** as icons in product UI. No custom hand-drawn SVG icons — stick to Lucide for consistency.
- **The logo** is the one bespoke mark; use `assets/janyaa-bcp-logo.png` directly, never a redraw.

---

## Caveats / open questions
- Colors are sampled from the supplied logo PNG; if there's an official brand hex sheet, swap the `--green/blue/gold/lime-500` anchors and the scales recompute around them.
- Fonts are Google Fonts substitutions chosen to fit the brand (the club has no defined typeface). Easy to change in one place if a real typeface is adopted.
- `Coral` (danger) is the only non-logo color — introduced because destructive actions need a red that isn't the gold.
