---
name: janyaa-hub-design-system
description: Design tokens, components, and usage rules for the Janyaa BCP Hub — a warm, credible club-operations platform for a STEM-education nonprofit. Use when building or styling any Janyaa Hub screen (member hours, events, fundraising, scouting) in React + Vite + Tailwind v4.
---

# Janyaa BCP Hub — Design System Skill

Apply this system to any Janyaa Hub UI. It is grounded in the club's actual logo: Bellarmine blue, Janyaa green, a rising-sun gradient, and two sprouting leaves.

## Files in this skill
- `README.md` — full reference: voice/content rules, color, type, spacing, elevation, iconography. **Read this first.**
- `colors_and_type.css` — source-of-truth CSS custom properties (framework-agnostic).
- `tailwind-theme.css` — Tailwind v4 `@theme` block. `@import` after `tailwindcss`.
- `style-guide.html` — open in a browser to see every token and component rendered.
- `ui_kits/janyaa-hub/` — reference implementation of the core screens (north-star, not production code).
- `assets/janyaa-bcp-logo.png` — the club badge.

## Quick start (React + Vite + Tailwind v4)
1. Copy `colors_and_type.css` + `tailwind-theme.css` into `src/styles/`.
2. In `src/index.css`:
   ```css
   @import "tailwindcss";
   @import "./styles/tailwind-theme.css";
   ```
3. Add the font `<link>` (Bricolage Grotesque, Hanken Grotesk, Space Mono) to `index.html`.
4. Install icons: `npm i lucide-react`.

## The 10-second rules
- **One green primary action per screen.** Green = go/approve/success.
- **Blue** = structure, nav, info, scheduled. **Gold** = fundraising, progress, "needs attention." **Lime** = decorative only. **Coral** = destructive only.
- **Warm neutrals**, never pure grey. App bg is warm paper; cards are near-white surface.
- **Type:** Bricolage (display/headings/numbers) · Hanken (UI/body) · Space Mono (overlines + tabular data). Never below 14px.
- **Sentence case** everywhere except Space Mono overlines (UPPERCASE). **Buttons are verbs** ("Approve hours"). **No emoji** in product UI.
- **Soft warm-tinted shadows**, 1px hairline borders, friendly radii (cards 18px, inputs 10px, pills full).
- **Icons:** Lucide, 2px stroke, 16–20px.

See `README.md` for the complete content + visual specification.
