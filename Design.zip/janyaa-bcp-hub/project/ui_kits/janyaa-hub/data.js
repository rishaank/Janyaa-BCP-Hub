// Janyaa Hub UI Kit — realistic placeholder data (from the club brief)
window.HUB = {
  approvals: [
    { who: 'Aayush', init: 'AY', color: 'var(--green-500)', title: 'Library STEM session', meta: 'Sat May 24 · "Ran the circuits experiment table"', hrs: '3.0' },
    { who: 'Ethan', init: 'ET', color: 'var(--blue-500)', title: 'Sunday Friends', meta: 'Sun May 25 · "Facilitated Lab-in-a-Box delivery"', hrs: '4.5' },
    { who: 'Anant', init: 'AN', color: 'var(--gold-600)', title: 'Location scouting', meta: 'Wed May 21 · "Called 4 restaurants re: Spirit Night"', hrs: '2.0' },
  ],
  members: [
    { name: 'Krishna R.', init: 'KR', color: 'var(--blue-500)', role: 'President', roleClass: 'b-blue', hrs: '38.0', mtgs: '12 / 12', status: 'Active', statusClass: 'b-green' },
    { name: 'Arjun P.', init: 'AP', color: 'var(--green-600)', role: 'Vice President', roleClass: 'b-blue', hrs: '34.5', mtgs: '11 / 12', status: 'Active', statusClass: 'b-green' },
    { name: 'Rishaan K.', init: 'RK', color: 'var(--gold-600)', role: 'Design & Socials', roleClass: 'b-neutral', hrs: '21.0', mtgs: '10 / 12', status: 'Active', statusClass: 'b-green' },
    { name: 'Aayush S.', init: 'AY', color: 'var(--green-500)', role: 'Member', roleClass: 'b-neutral', hrs: '27.5', mtgs: '9 / 12', status: 'Active', statusClass: 'b-green' },
    { name: 'Abhijay M.', init: 'AB', color: 'var(--coral-500)', role: 'Member', roleClass: 'b-neutral', hrs: '18.0', mtgs: '8 / 12', status: 'Active', statusClass: 'b-green' },
    { name: 'Anant V.', init: 'AN', color: 'var(--gold-600)', role: 'Treasurer', roleClass: 'b-blue', hrs: '24.0', mtgs: '11 / 12', status: 'Active', statusClass: 'b-green' },
    { name: 'Ethan L.', init: 'ET', color: 'var(--blue-500)', role: 'Secretary', roleClass: 'b-blue', hrs: '29.0', mtgs: '10 / 12', status: 'Active', statusClass: 'b-green' },
    { name: 'Aarush T.', init: 'AT', color: 'var(--green-700)', role: 'PR', roleClass: 'b-blue', hrs: '15.5', mtgs: '6 / 12', status: 'At risk', statusClass: 'b-gold' },
  ],
  events: [
    { d: '31', mo: 'May', name: 'Library STEM session', loc: 'West Valley Branch', type: 'Library', status: 'Scheduled', sClass: 'b-blue' },
    { d: '01', mo: 'Jun', name: 'Vasona lemonade stand', loc: 'Vasona Park', type: 'Vasona', status: 'Scheduled', sClass: 'b-blue' },
    { d: '18', mo: 'May', name: 'Sunday Friends', loc: 'San Jose', type: 'Sunday Friends', status: 'Complete', sClass: 'b-green' },
    { d: '10', mo: 'May', name: "St. Andrew's session", loc: "St. Andrew's", type: "St. Andrew's", status: 'Complete', sClass: 'b-green' },
    { d: '15', mo: 'Mar', name: 'EVSFM spring fundraiser', loc: 'Community Market', type: 'EVSFM', status: 'Complete', sClass: 'b-green' },
    { d: '22', mo: 'Feb', name: 'Kickoff & planning', loc: 'BCP campus', type: 'Other', status: 'Complete', sClass: 'b-green' },
  ],
  fund: [
    { name: 'EVSFM spring fundraiser', date: 'Mar 15, 2026', type: 'EVSFM', typeClass: 'b-gold', raised: '$520', status: 'Counted', sClass: 'b-green' },
    { name: 'GoFundMe — winter drive', date: 'Nov 2025', type: 'Online', typeClass: 'b-blue', raised: '$480', status: 'Counted', sClass: 'b-green' },
    { name: 'Vasona lemonade stand', date: 'Jun 1, 2026', type: 'Vasona', typeClass: 'b-neutral', raised: '$230', status: 'Projected', sClass: 'b-gold' },
    { name: 'Chipotle Spirit Night', date: 'Jun 14, 2026', type: 'Restaurant', typeClass: 'b-neutral', raised: '—', status: 'Prospect', sClass: 'b-neutral' },
  ],
  // San Jose area scouting locations
  locations: [
    { name: 'Vasona Park', addr: 'Los Gatos · summer lemonade', lat: 37.2466, lng: -121.9686, status: 'Partner', sClass: 'b-green', color: 'var(--green-500)' },
    { name: 'West Valley Library', addr: 'San Jose · STEM sessions', lat: 37.2872, lng: -121.9869, status: 'Partner', sClass: 'b-green', color: 'var(--green-500)' },
    { name: "Sunday Friends", addr: 'San Jose · partner site', lat: 37.3496, lng: -121.8761, status: 'Partner', sClass: 'b-green', color: 'var(--green-500)' },
    { name: 'Community Market', addr: 'San Jose · EVSFM fundraiser', lat: 37.3337, lng: -121.8907, status: 'Approved', sClass: 'b-blue', color: 'var(--blue-500)' },
    { name: 'Chipotle — Westgate', addr: 'San Jose · Spirit Night?', lat: 37.2799, lng: -121.9920, status: 'Contacted', sClass: 'b-gold', color: 'var(--gold-500)' },
    { name: "Panera — Stevens Creek", addr: 'San Jose · prospect', lat: 37.3229, lng: -121.9510, status: 'Prospect', sClass: 'b-neutral', color: 'var(--neutral-500)' },
    { name: 'Round Table Pizza', addr: 'Campbell · declined', lat: 37.2872, lng: -121.9500, status: 'Declined', sClass: 'b-coral', color: 'var(--coral-500)' },
  ],
};
