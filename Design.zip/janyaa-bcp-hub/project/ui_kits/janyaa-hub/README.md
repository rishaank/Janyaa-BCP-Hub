# Janyaa Hub — UI Kit

A high-fidelity, interactive recreation of the Janyaa BCP Hub's core screens, built **with this design system** so it can serve as a north-star when building the real React + Vite + Tailwind v4 app.

It is a **cosmetic prototype**, not production code — view switching and interactions are mocked with vanilla JS and realistic placeholder data from the club brief.

## Open
`index.html` — the full app shell with switchable views:

- **Dashboard** — term overview, key stats, fundraising progress, pending approvals, upcoming events
- **Members & Hours** — member directory + the hours approval flow (Module 1)
- **Events** — event roster with roles, RSVP, attendance (Module 2)
- **Fundraising** — totals, term progress, per-event breakdown, year-over-year (Module 3)
- **Scouting Map** — interactive Leaflet map of fundraising locations by status (Module 4 / V2)
- **AI Insights** — post-event pattern surfacing (Module 8 / V3)

## Dependencies (CDN)
- Lucide icons
- Leaflet + OpenStreetMap (scouting map — free, no API key)
- Fonts + tokens via `../../colors_and_type.css`
