// Janyaa Hub UI Kit — interactions
(function () {
  const H = window.HUB;

  // ---------- view switching ----------
  const titles = {
    dashboard: 'Dashboard', members: 'Members & Hours', events: 'Events',
    fundraising: 'Fundraising', map: 'Scouting Map', insights: 'AI Insights',
  };
  let mapReady = false;
  function go(view) {
    document.querySelectorAll('.navbtn').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.dataset.view === view));
    document.getElementById('pageTitle').textContent = titles[view] || 'Dashboard';
    closeSide();
    if (view === 'map') initMap();
    window.scrollTo({ top: 0 });
  }
  document.querySelectorAll('.navbtn').forEach(b => b.addEventListener('click', () => go(b.dataset.view)));

  // ---------- mobile sidebar ----------
  const side = document.getElementById('side'), scrim = document.getElementById('scrim');
  function openSide() { side.classList.add('open'); scrim.classList.add('show'); }
  function closeSide() { side.classList.remove('open'); scrim.classList.remove('show'); }
  document.getElementById('menuToggle').addEventListener('click', openSide);
  scrim.addEventListener('click', closeSide);

  // ---------- approval rows ----------
  function approvalRow(a) {
    const el = document.createElement('div');
    el.className = 'list-row';
    el.innerHTML = `
      <span class="avatar" style="background:${a.color}">${a.init}</span>
      <div class="who"><b>${a.who} — ${a.title}</b><span>${a.meta}</span></div>
      <span class="mono" style="font-weight:700;font-size:var(--text-sm)">${a.hrs} hrs</span>
      <button class="btn btn-primary btn-sm"><i data-lucide="check"></i>Approve</button>
      <button class="btn btn-ghost btn-sm" aria-label="Decline"><i data-lucide="x"></i></button>`;
    // mock approve interaction
    el.querySelector('.btn-primary').addEventListener('click', () => {
      el.style.transition = 'opacity .25s, transform .25s';
      el.style.opacity = '0'; el.style.transform = 'translateX(12px)';
      setTimeout(() => el.remove(), 250);
    });
    el.querySelector('.btn-ghost').addEventListener('click', () => {
      el.style.opacity = '.4';
    });
    return el;
  }
  ['approvalList', 'approvalList2'].forEach(id => {
    const host = document.getElementById(id);
    if (host) H.approvals.forEach(a => host.appendChild(approvalRow(a)));
  });

  // ---------- member table ----------
  const mr = document.getElementById('memberRows');
  H.members.forEach(m => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><div class="cell-name"><span class="avatar" style="background:${m.color};width:32px;height:32px;font-size:var(--text-xs)">${m.init}</span><b>${m.name}</b></div></td>
      <td><span class="badge ${m.roleClass}">${m.role}</span></td>
      <td class="mono" style="font-weight:600">${m.hrs}</td>
      <td class="mono" style="color:var(--text-secondary)">${m.mtgs}</td>
      <td><span class="badge ${m.statusClass}">${m.status}</span></td>`;
    mr.appendChild(tr);
  });

  // ---------- events grid ----------
  const eg = document.getElementById('eventGrid');
  H.events.forEach(e => {
    const card = document.createElement('div');
    card.className = 'card ev-card';
    card.innerHTML = `
      <div style="display:flex;gap:var(--space-3);align-items:flex-start">
        <div class="date"><b>${e.d}</b><span>${e.mo}</span></div>
        <div style="flex:1;min-width:0">
          <b style="font-family:var(--font-display);font-weight:600;font-size:var(--text-h4);display:block">${e.name}</b>
          <span style="font-size:var(--text-xs);color:var(--text-muted)">${e.loc}</span>
        </div>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--border);padding-top:var(--space-3)">
        <span class="badge b-neutral">${e.type}</span>
        <span class="badge ${e.sClass}">${e.status}</span>
      </div>`;
    eg.appendChild(card);
  });

  // ---------- fundraising table ----------
  const fr = document.getElementById('fundRows');
  H.fund.forEach(f => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><b style="font-weight:600">${f.name}</b></td>
      <td style="color:var(--text-secondary)">${f.date}</td>
      <td><span class="badge ${f.typeClass}">${f.type}</span></td>
      <td class="mono" style="font-weight:700">${f.raised}</td>
      <td><span class="badge ${f.sClass}">${f.status}</span></td>`;
    fr.appendChild(tr);
  });

  // ---------- location list ----------
  const ll = document.getElementById('locList');
  H.locations.forEach((l, i) => {
    const el = document.createElement('div');
    el.className = 'card loc';
    el.dataset.idx = i;
    el.innerHTML = `
      <div class="ln"><b>${l.name}</b><span class="badge ${l.sClass}">${l.status}</span></div>
      <div class="addr">${l.addr}</div>`;
    el.addEventListener('click', () => focusMarker(i));
    ll.appendChild(el);
  });

  // ---------- Leaflet map ----------
  let map, markers = [];
  function pinIcon(color) {
    return L.divIcon({ className: '', html: `<div class="leaflet-pin" style="background:${color}"></div>`, iconSize: [18, 18], iconAnchor: [9, 18] });
  }
  function initMap() {
    if (mapReady) { setTimeout(() => map.invalidateSize(), 50); return; }
    mapReady = true;
    map = L.map('map', { scrollWheelZoom: false }).setView([37.305, -121.92], 12);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap &copy; CARTO', subdomains: 'abcd', maxZoom: 19,
    }).addTo(map);
    H.locations.forEach((l, i) => {
      // resolve CSS var to a real color for the SVG pin
      const probe = document.createElement('div'); probe.style.color = l.color; document.body.appendChild(probe);
      const rgb = getComputedStyle(probe).color; probe.remove();
      const m = L.marker([l.lat, l.lng], { icon: pinIcon(rgb) }).addTo(map);
      m.bindPopup(`<strong style="font-family:var(--font-sans)">${l.name}</strong><br><span style="color:#666;font-size:12px">${l.addr} · ${l.status}</span>`);
      markers.push(m);
    });
    setTimeout(() => map.invalidateSize(), 60);
  }
  window.focusMarker = function (i) {
    if (!mapReady) return;
    const l = H.locations[i];
    map.setView([l.lat, l.lng], 14, { animate: true });
    markers[i].openPopup();
    document.querySelectorAll('.loc').forEach(x => x.style.borderColor = '');
    const card = document.querySelector(`.loc[data-idx="${i}"]`);
    if (card) card.style.borderColor = 'var(--green-500)';
  };

  lucide.createIcons();
})();
